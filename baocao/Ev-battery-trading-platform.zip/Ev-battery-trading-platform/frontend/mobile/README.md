# Frontend Mobile

App mobile sử dụng Flutter / React Native

## Cấu trúc
```
mobile/
├── lib/ (Flutter) hoặc src/ (React Native)
│   ├── screens/
│   ├── components/
│   ├── services/
│   └── utils/
├── package.json hoặc pubspec.yaml
└── README.md
```

