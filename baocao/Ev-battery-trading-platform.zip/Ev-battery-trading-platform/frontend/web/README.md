# Frontend Web

Giao diện web sử dụng React / Next.js

## Cấu trúc
```
web/
├── src/
│   ├── components/
│   ├── pages/
│   ├── services/
│   └── utils/
├── package.json
└── README.md
```

