# Analytics Service

Thống kê

## Chức năng
- Thu thập dữ liệu thống kê
- Phân tích dữ liệu
- Báo cáo thống kê

## Cấu trúc
```
analytics-service/
├── src/
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   └── consumers/
├── index.js
├── package.json
└── README.md
```

