# Wishlist Service

Danh sách yêu thích

## Chức năng
- Thêm vào wishlist
- Xóa khỏi wishlist
- Lấy danh sách wishlist

## Cấu trúc
```
wishlist-service/
├── src/
│   ├── controllers/
│   ├── models/
│   └── routes/
├── index.js
├── package.json
└── README.md
```

