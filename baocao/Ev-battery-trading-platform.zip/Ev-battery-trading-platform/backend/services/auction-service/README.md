# Auction Service

Đấu giá

## Chức năng
- Tạo phiên đấu giá
- Đặt giá thầu
- Quản lý phiên đấu giá
- Kết thúc đấu giá

## Cấu trúc
```
auction-service/
├── src/
│   ├── controllers/
│   ├── models/
│   └── routes/
├── index.js
├── package.json
└── README.md
```

