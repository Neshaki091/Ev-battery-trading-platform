# Report Service

Báo cáo bài đăng, người dùng

## Chức năng
- Tạo báo cáo
- Xử lý báo cáo
- Quản lý trạng thái báo cáo

## Cấu trúc
```
report-service/
├── src/
│   ├── controllers/
│   ├── models/
│   └── routes/
├── index.js
├── package.json
└── README.md
```

