# Review Service

Đánh giá bài đăng

## Chức năng
- Tạo đánh giá
- Cập nhật đánh giá
- Xóa đánh giá
- Lấy danh sách đánh giá

## Cấu trúc
```
review-service/
├── src/
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   └── repositories/
├── server.js
├── package.json
└── README.md
```

