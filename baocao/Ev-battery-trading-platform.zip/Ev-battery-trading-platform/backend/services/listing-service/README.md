# Listing Service

CRUD tin đăng xe/pin

## Chức năng
- Tạo tin đăng
- Cập nhật tin đăng
- Xóa tin đăng
- Lấy danh sách tin đăng
- Lấy chi tiết tin đăng

## Cấu trúc
```
listing-service/
├── src/
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   └── middleware/
├── server.js
├── package.json
└── README.md
```

