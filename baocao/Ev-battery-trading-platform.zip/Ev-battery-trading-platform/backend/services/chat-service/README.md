# Chat Service

Nhắn tin giữa người bán và người mua

## Chức năng
- Tạo phòng chat
- Gửi tin nhắn
- Lấy lịch sử chat
- Quản lý phòng chat

## Cấu trúc
```
chat-service/
├── controllers/
├── routes/
├── util/
├── index.js
├── package.json
└── README.md
```

