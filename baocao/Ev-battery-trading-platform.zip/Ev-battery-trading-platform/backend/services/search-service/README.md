# Search Service

Tìm kiếm, lọc, gợi ý

## Chức năng
- Tìm kiếm tin đăng
- Lọc theo tiêu chí
- Gợi ý tìm kiếm
- Sắp xếp kết quả

## Cấu trúc
```
search-service/
├── src/
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   └── services/
├── server.js
├── package.json
└── README.md
```

