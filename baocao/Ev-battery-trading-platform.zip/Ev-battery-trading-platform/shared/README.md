# Shared

Code, types, utils dùng chung giữa frontend và backend

## Nội dung
- Common types/interfaces
- Shared utilities
- Constants
- Validation schemas

## Cấu trúc
```
shared/
├── types/
├── utils/
└── constants/
```

